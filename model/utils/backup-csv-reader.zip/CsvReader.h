#ifndef CSVREADER_H
#define CSVREADER_H

#include <QtCore/qstring.h>
#include <QtCore/qhash.h>
#include <QtCore/qstringlist.h>
#include <QtCore/qlist.h>

#include "CsvHeader.h"

struct DataFromCsv {
    CsvHeader header;
    QList<QStringList> lines;
};

class CsvReader
{
public:
    CsvReader(const QString &fileName,
              QString sep = ",",
              QString guillemetsForString = "",
              bool hasHeader = true,
              QString returnLine = "\n");
    static bool isLinuxReturnLine(QString &fileName);
    static bool isValidHeader(
            const QString &fileName, const QStringList &elements);

    bool isValidHeader(const QStringList &elements) const;
    bool readAll();
    bool readSomeLines(int nLines);
    const DataFromCsv *dataRode() const;
    void removeFirstLine();
    QStringList takeFirstLine();

private:
    QStringList decodeLine(const QString &line) const;
    QString m_fileName;
    QString m_guillemetsForString;
    bool m_hasHeader;
    QString m_sep;
    QString m_returnLine;
    DataFromCsv m_dataRode;
};


#endif // CSVREADER_H

#include <QtCore/qfile.h>
#include <QtCore/qtextstream.h>

#include "CsvReader.h"


//----------------------------------------------------------
CsvReader::CsvReader(
        const QString &fileName,
        QString sep,
        QString guillemetsForString,
        bool hasHeader,
        QString returnLine)
{
    m_fileName = fileName;
    m_sep = sep;
    m_hasHeader = hasHeader;
    m_guillemetsForString = guillemetsForString;
    m_returnLine = returnLine;
}
//----------------------------------------------------------
bool CsvReader::isLinuxReturnLine(QString &fileName)
{
    bool is = false;
    QFile file(fileName);
    if (file.open(QIODevice::ReadOnly)) {
        QTextStream stream(&file);
        QString line = stream.readLine();
        file.seek(0);
        QString firstData = stream.read(line.length()*2+2);
        is = !firstData.contains("\r\n");
        file.close();
    }
    return is;
}
//----------------------------------------------------------
bool CsvReader::isValidHeader(
        const QString &fileName, const QStringList &elements)
{
    bool is = false;
    QFile file(fileName);
    if (file.open(QIODevice::ReadOnly)) {
        QTextStream stream(&file);
        QString line = stream.readLine();
        is = true;
        for (auto element : elements) {
            if (!line.contains(element)){
                is = false;
                break;
            }
        }
        file.close();
    }
    return is;
}
//----------------------------------------------------------
bool CsvReader::isValidHeader(const QStringList &elements) const
{
    bool is = CsvReader::isValidHeader(m_fileName, elements);
    return is;
}
//----------------------------------------------------------
bool CsvReader::readAll()
{
    m_dataRode.lines.clear();
    QFile file(m_fileName);
    if (file.open(QIODevice::ReadOnly)) {
        QTextStream stream(&file);
        QString line = stream.readLine();
        if (m_hasHeader) {
            QStringList headerElements = decodeLine(line);
            m_dataRode.header = CsvHeader(headerElements);
        }
        while (true) {
            line = stream.readLine();
            line = line.replace("\"\"", "''");
            if (line.isEmpty()) {
                break;
            } else {
                QStringList decodedLine = decodeLine(line);
                m_dataRode.lines << decodedLine;
            }
        }
        file.close();
        return true;
    }
    return false;
}
//----------------------------------------------------------
bool CsvReader::readSomeLines(int nLines)
{
    m_dataRode.lines.clear();
    QFile file(m_fileName);
    if (file.open(QIODevice::ReadOnly)) {
        QTextStream stream(&file);
        QString line = stream.readLine();
        if (m_hasHeader) {
            QStringList headerElements = decodeLine(line);
            m_dataRode.header = CsvHeader(headerElements);
        }
        int curLine = 0;
        while (curLine < nLines) {
            line = stream.readLine();
            line = line.replace("\"\"", "''");
            if (line.isEmpty()) {
                break;
            } else {
                QStringList decodedLine = decodeLine(line);
                m_dataRode.lines << decodedLine;
            }
            ++curLine;
        }
        file.close();
        return true;
    }
    return false;
}
//----------------------------------------------------------
const DataFromCsv *CsvReader::dataRode() const
{
    return &m_dataRode;
}
//----------------------------------------------------------
void CsvReader::removeFirstLine()
{
    if (m_dataRode.lines.size() > 0) {
        m_dataRode.lines.removeAt(0);
    }
}
//----------------------------------------------------------
QStringList CsvReader::takeFirstLine()
{
    QStringList elements = m_dataRode.lines.takeAt(0);
    return elements;
}
//----------------------------------------------------------
QStringList CsvReader::decodeLine(const QString &line) const
{
    QStringList elements;
    if (m_guillemetsForString.isEmpty()) {
        elements = line.split(m_sep);
    } else {
        int lenSep = m_sep.length();
        int lenGuill = m_guillemetsForString.length();
        QString lineCopy = line.trimmed();
        bool end = false;
        while(!end) {
            if (lineCopy.startsWith(m_guillemetsForString)) {
                lineCopy.remove(0, lenGuill);
                int indexEnd = lineCopy.indexOf(m_guillemetsForString);
                QString element = lineCopy.left(indexEnd);
                elements << element;
                lineCopy.remove(0, indexEnd + lenSep + lenGuill);
            } else {
                int indexEnd = lineCopy.indexOf(m_sep);
                QString element = lineCopy.left(indexEnd);
                elements << element;
                lineCopy.remove(0, indexEnd + lenSep);
            }
            end = lineCopy.isEmpty();
        }
    }
    return elements;
}
//----------------------------------------------------------

